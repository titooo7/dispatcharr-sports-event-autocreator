"""
Celery task and beat-schedule management for the Sports Event Auto-Creator.

The @shared_task below is registered when this module is imported. Dispatcharr
imports enabled plugin modules in the web workers (app ready) and, per-process,
in every Celery worker process — but WHICH signal triggers that varies by
Dispatcharr version and, critically, only reliably covers `--pool=threads`
workers (no parent/child split) or prefork CHILD processes, never a prefork
ARBITER (the process that validates/dispatches incoming messages). Routing
this task to the `dvr` queue (a `--pool=threads` worker on every standard
Dispatcharr install) sidesteps that entirely — see the long comment above
the `@shared_task(..., queue="dvr")` decorator further down for the full
story of why a plugin-side signal hook cannot fix the arbiter case.

Celery Beat itself never imports plugin modules at all (Dispatcharr's own
apps.py skips discovery for any process with 'celery'/'beat' in argv), so
Beat has no idea this task's decorator says queue="dvr" — it only routes by
the PeriodicTask row's own `queue` field or the app's static task_routes,
neither of which knew about this task otherwise. Without `queue="dvr"` set
explicitly in sync_schedule()'s update_or_create() below, Beat silently
dispatched every run to the default `celery` queue, which depends on the
same fragile prefork-child registration described above — worked by luck of
which autoscaled child got forked when, until it didn't (confirmed broken
for ~17h straight after a routine celery container rebuild, 2026-07-20/21).
Setting `queue="dvr"` on the PeriodicTask makes Beat route correctly no
matter what any worker process has or hasn't registered.

The user-selected run frequency (interval_minutes or cron_expression settings)
is materialized as a django_celery_beat PeriodicTask that calls this task.
"""

import json
import logging
import os
import traceback
from datetime import datetime, timezone

from celery import shared_task

PLUGIN_KEY = "sports_event_autocreator"
TASK_NAME = f"{PLUGIN_KEY}.run_jobs"
PERIODIC_TASK_NAME = "sports-event-autocreator-run-jobs"

# Written after every task execution; read by the 'Show status' action.
# Legacy (pre-1.2.0) in-package location -- _last_run_file_path() below
# migrates it once to runner.plugin_state_dir(), which survives a plugin
# re-import (unlike this old location, which the update process wipes).
_LEGACY_LAST_RUN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "last_run.json")

logger = logging.getLogger(f"plugins.{PLUGIN_KEY}")


def _last_run_file_path() -> str:
    from . import runner
    new_path = os.path.join(runner.plugin_state_dir(), "last_run.json")
    runner._migrate_legacy_state_file(new_path, _LEGACY_LAST_RUN_FILE, logger)
    return new_path

# ---------------------------------------------------------------------------
# Workaround for a Dispatcharr/celery interaction bug:
#
# Dispatcharr imports plugin modules in the celery worker via the
# `worker_ready` signal, which fires AFTER the consumer's Tasks bootstep has
# already built its task-dispatch table (`update_strategies()`). Tasks
# registered that late show up in `inspect registered` but every delivery is
# discarded with "Received unregistered task ... KeyError" — celery never
# re-checks the registry (verified against celery 5.6.3 source).
#
# Remote control commands, however, ARE dispatched dynamically. So we
# register one that rebuilds the dispatch table, and broadcast it right
# after import inside a worker process: by the time the worker's event loop
# starts consuming, the command is waiting and heals the table.
#
# Second half of the same bug: with a prefork pool the child processes are
# forked BEFORE worker_ready fires, so a child forked at boot never imports
# the plugin at all — the (healed) parent accepts a delivery, hands it to
# that child, and the child raises NotRegistered. Children forked later
# (autoscale scaling up under load) inherit the import and work, which makes
# the failure look random. The refresh command therefore also recycles those
# pre-plugin children: each one is replaced via terminate_controlled() — the
# same graceful mechanism pool shrink / autoscale uses — and the pool
# maintainer respawns a fresh child that inherits the plugin import. Busy
# children are skipped and retried on the next refresh (one runs before every
# queued run). Note pool.restart() can NOT be used for this: celery only
# creates billiard's restart sentinels when worker_pool_restarts is enabled
# (Dispatcharr doesn't), so restart() crashes on the None sentinel.
# Thread/solo pools run tasks in the main process — already healed — and are
# detected and skipped.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Dispatcharr >= 0.28.0: the ARBITER (prefork parent / consumer) process no
# longer imports plugin modules at all. Discovery moved from `worker_ready`
# (fires once, in the arbiter) to `worker_process_init` (fires per prefork
# CHILD, deliberately skipping the parent so it never opens DB connections
# autoscale children would inherit via fork — see dispatcharr/celery.py).
#
# For a `--pool=threads` worker (this Dispatcharr's `dvr` queue) there is no
# separate child process, so that single process is both "arbiter" and
# "worker" and gets the plugin import either way. But for a
# `--pool=prefork --autoscale=...` worker (the `celery`/default queue this
# task was previously routed to), the ARBITER (parent) process never imports
# any plugin module at all, by design — only its prefork children do, on
# their own worker_process_init. The arbiter is the process that actually
# validates/dispatches every incoming message (children only execute work
# already handed to them), so nothing a child does — and no signal hook a
# plugin can add, since hooking a signal itself requires the module to
# already be imported in that same process — can retroactively fix the
# arbiter's registry. Confirmed by direct testing (Dispatcharr 0.28.0): the
# arbiter's own `app.tasks` picks up a manually-triggered import fine, and
# even an explicit `consumer.update_strategies()` call in that same process
# doesn't help, because the fix can never actually run *in* the arbiter in
# the first place — its own `worker_ready` fires before any plugin-supplied
# signal handler could ever be connected there.
#
# Fix: route this task to the `dvr` queue instead — the one queue guaranteed
# to be served by a `--pool=threads` worker (no prefork parent/child split)
# on every Dispatcharr install using the standard entrypoint. Trade-off:
# job-creation runs share the dvr queue's thread pool with real recording
# tasks; at the default `--concurrency=20` and typical run frequency this
# is not a practical concern, but note it if that pool is ever narrowed.
#
# An earlier version of this file carried a custom `sea_refresh_strategies`
# celery control command + a "recycle stale pool children" mechanism, to
# heal prefork children forked before this module was imported (a real
# problem when this task ran on the prefork `celery` queue). Removed: since
# the task now runs exclusively on the thread-pool `dvr` queue, there is no
# forking involved at all — no child process can ever be "stale" relative
# to this task, on any Dispatcharr version. The custom command served no
# remaining purpose but still got broadcast on every "Run now" click (see
# `check_worker_ready()` below, which replaced it) and, since the `celery`
# queue's arbiter can never have a custom command it never imported, that
# broadcast reliably produced a harmless-but-alarming `KeyError('sea_
# refresh_strategies')` in the logs on every single click.


def _get_celery_app():
    try:
        from dispatcharr.celery import app
        return app
    except Exception:
        from celery import current_app
        return current_app


def check_worker_ready() -> bool:
    """Whether at least one live celery worker knows about this task.

    Uses celery's built-in `registered` inspect command — unlike a custom
    control command, every worker (including a prefork arbiter that never
    imported this plugin) always has a handler for it, so this can never
    itself produce a "command error" the way probing for a custom command
    can. Returns False (never raises) if nothing answers in time.
    """
    try:
        app = _get_celery_app()
        replies = app.control.inspect(timeout=2.0).registered() or {}
        # Each entry is normally just the bare task name, but celery's
        # `registered` command appends "[attr=val ...]" when the task has
        # non-default exchange/routing_key/rate_limit — substring match to
        # stay correct either way.
        return any(TASK_NAME in entry for entries in replies.values() for entry in entries)
    except Exception:
        logger.debug("Worker-readiness check failed", exc_info=True)
        return False


def _write_last_run(payload: dict, mark_success: bool = False) -> None:
    """Write last_run.json. `last_success_at`/`last_success_summary` are
    ALWAYS carried forward from whatever was there before, regardless of
    this call's outcome; only the call site for a genuinely successful full
    run passes mark_success=True to overwrite them with this run's result.
    Every other call site (skips, config errors, dry runs, crashes) must
    leave the last known success alone."""
    try:
        path = _last_run_file_path()
        payload = dict(payload)
        payload["finished_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")

        prev = {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                prev = json.load(f) or {}
        except Exception:
            prev = {}

        payload["last_success_at"] = prev.get("last_success_at")
        payload["last_success_summary"] = prev.get("last_success_summary")
        if mark_success:
            payload["last_success_at"] = payload["finished_at"]
            payload["last_success_summary"] = payload.get("summary") or ""

        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
    except Exception:
        logger.debug("Could not write last_run.json", exc_info=True)


def read_last_run() -> dict | None:
    try:
        with open(_last_run_file_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _get_plugin_config():
    from apps.plugins.models import PluginConfig
    return PluginConfig.objects.filter(key=PLUGIN_KEY).first()


# ---------------------------------------------------------------------------
# Beat schedule management
# ---------------------------------------------------------------------------

def describe_schedule(settings: dict) -> str:
    cron = (settings.get("cron_expression") or "").strip()
    if cron:
        return f"cron '{cron}'"
    try:
        minutes = int(float(settings.get("interval_minutes") or 0))
    except (TypeError, ValueError):
        minutes = 0
    if minutes > 0:
        return f"every {minutes} minute(s)"
    return "disabled (interval is 0 and no cron expression set)"


def sync_schedule(settings: dict) -> str:
    """
    Create/update/disable the beat PeriodicTask to match the plugin settings.
    Returns a human-readable description of the resulting schedule.
    """
    from django_celery_beat.models import CrontabSchedule, IntervalSchedule, PeriodicTask
    from core.models import CoreSettings

    cron = (settings.get("cron_expression") or "").strip()
    try:
        minutes = int(float(settings.get("interval_minutes") or 0))
    except (TypeError, ValueError):
        minutes = 0

    existing = PeriodicTask.objects.filter(name=PERIODIC_TASK_NAME).first()
    old_interval = existing.interval if existing else None
    old_crontab = existing.crontab if existing else None

    if cron:
        parts = cron.split()
        if len(parts) != 5:
            raise ValueError("Cron expression must have 5 parts: minute hour day month weekday")
        # Validate the fields with celery before persisting: a bad expression
        # (e.g. hour '8-25') saved to django_celery_beat can crash the beat
        # process, which drives ALL of Dispatcharr's scheduled work.
        try:
            from celery.schedules import crontab as _celery_crontab
            _celery_crontab(minute=parts[0], hour=parts[1], day_of_month=parts[2],
                            month_of_year=parts[3], day_of_week=parts[4])
        except Exception as e:
            raise ValueError(f"Invalid cron expression '{cron}': {e}")
        try:
            system_tz = CoreSettings.get_system_time_zone()
        except Exception:
            system_tz = "UTC"
        crontab, _ = CrontabSchedule.objects.get_or_create(
            minute=parts[0], hour=parts[1], day_of_month=parts[2],
            month_of_year=parts[3], day_of_week=parts[4], timezone=system_tz,
        )
        PeriodicTask.objects.update_or_create(
            name=PERIODIC_TASK_NAME,
            defaults={"task": TASK_NAME, "crontab": crontab, "interval": None,
                      "enabled": True, "kwargs": "{}", "queue": "dvr"},
        )
    elif minutes > 0:
        interval, _ = IntervalSchedule.objects.get_or_create(
            every=minutes, period=IntervalSchedule.MINUTES,
        )
        PeriodicTask.objects.update_or_create(
            name=PERIODIC_TASK_NAME,
            defaults={"task": TASK_NAME, "interval": interval, "crontab": None,
                      "enabled": True, "kwargs": "{}", "queue": "dvr"},
        )
    else:
        # Disabled: keep the row but switch it off so beat stops firing.
        PeriodicTask.objects.filter(name=PERIODIC_TASK_NAME).update(enabled=False)

    _cleanup_orphans(old_interval, old_crontab)
    desc = describe_schedule(settings)
    logger.info("Schedule synced: %s", desc)
    return desc


def disable_schedule() -> None:
    """Switch the periodic task off (plugin disabled in the UI)."""
    try:
        from django_celery_beat.models import PeriodicTask
        PeriodicTask.objects.filter(name=PERIODIC_TASK_NAME).update(enabled=False)
        logger.info("Periodic task disabled")
    except Exception:
        logger.exception("Failed to disable periodic task")


def delete_schedule() -> None:
    """Remove the periodic task entirely (plugin deleted), so beat doesn't
    keep dispatching a task that no longer exists."""
    try:
        from django_celery_beat.models import PeriodicTask
        existing = PeriodicTask.objects.filter(name=PERIODIC_TASK_NAME).first()
        if existing:
            old_interval, old_crontab = existing.interval, existing.crontab
            existing.delete()
            _cleanup_orphans(old_interval, old_crontab)
            logger.info("Periodic task deleted")
    except Exception:
        logger.exception("Failed to delete periodic task")


def _cleanup_orphans(old_interval, old_crontab):
    """Delete schedule rows no longer referenced by any PeriodicTask."""
    from django_celery_beat.models import PeriodicTask
    try:
        if old_interval and not PeriodicTask.objects.filter(interval=old_interval).exists():
            old_interval.delete()
        if old_crontab and not PeriodicTask.objects.filter(crontab=old_crontab).exists():
            old_crontab.delete()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# The scheduled/queued task
# ---------------------------------------------------------------------------

@shared_task(name=TASK_NAME, queue="dvr")
def run_jobs_task(job_name: str = "", dry_run: bool = False) -> dict:
    """
    Run all enabled jobs (or a single job when job_name is given).
    Fired by Celery beat on the user-configured schedule and queued by the
    plugin's UI actions via .delay().
    """
    # Fix (v1.2.0): these three imports used to sit OUTSIDE the try/except
    # below. If runner.py (or engine.py) itself failed to import -- exactly
    # the scenario most likely right after a bad plugin update, which is
    # precisely what the top-level crash handler exists to catch -- the
    # exception escaped the handler entirely (no last_run.json write, no
    # notification), and then the `finally` block's use of `cache`/
    # `close_old_connections` raised a SECOND, unrelated NameError since
    # neither name was ever bound. Pre-bind both to None so the `finally`
    # block can never raise NameError regardless of where import/execution
    # fails, then do the real imports INSIDE the try so any failure there is
    # caught by the same top-level handler, on every single run (not just
    # once at plugin-load time).
    close_old_connections = None
    cache = None
    lock_key = f"{PLUGIN_KEY}:run_lock"
    lock_acquired = False
    try:
        from django.db import close_old_connections
        from django.core.cache import cache
        from . import engine, runner

        # Non-blocking overlap guard: if a run outlasts the beat interval or
        # "Run now" is pressed mid-run, two tasks over the same groups race
        # (duplicate channels, delete/create conflicts). A cache lock lets
        # the second bail out.
        try:
            lock_acquired = bool(cache.add(
                lock_key, datetime.now(timezone.utc).isoformat(), timeout=1800))
        except Exception:
            # Cache backend unavailable — never let a lock failure mask the run.
            logger.debug("Run-lock cache.add failed; proceeding without a lock",
                         exc_info=True)
        else:
            if not lock_acquired:
                logger.warning("Another run is already in progress; skipping this run")
                result = {"status": "skipped",
                          "reason": "another run is already in progress"}
                _write_last_run(result)
                return result

        cfg = _get_plugin_config()
        if not cfg or not cfg.enabled:
            logger.info("Plugin is disabled; skipping run")
            _write_last_run({"status": "skipped", "reason": "plugin disabled"})
            return {"status": "skipped", "reason": "plugin disabled"}

        settings = cfg.settings or {}

        # Self-heal: if the user changed the interval/cron in settings but
        # didn't press "Apply schedule", re-sync on this tick.
        try:
            sync_schedule(settings)
        except Exception:
            logger.exception("Schedule self-heal failed (continuing with run)")

        engine.set_display_timezone(settings.get("display_timezone") or "Europe/Madrid")

        jobs, config_errors = runner.jobs_from_settings(settings)
        for err in config_errors:
            logger.error("Invalid job configuration: %s", err)
        if config_errors and not jobs:
            _notify(f"Sports Auto-Creator: invalid configuration — {config_errors[0]}",
                    success=False)
            _write_last_run({"status": "error", "errors": config_errors})
            return {"status": "error", "message": " | ".join(config_errors)}

        if job_name:
            jobs = [j for j in jobs if j.name.lower() == job_name.strip().lower()]
            if not jobs:
                msg = f"No job named '{job_name}' found"
                logger.error(msg)
                _notify(f"Sports Auto-Creator: {msg}", success=False)
                _write_last_run({"status": "error", "errors": [msg]})
                return {"status": "error", "message": msg}

        jobs = [j for j in jobs if j.enabled]
        if not jobs:
            logger.info("No enabled jobs to run")
            _write_last_run({"status": "ok", "summary": "No enabled jobs"})
            return {"status": "ok", "message": "No enabled jobs"}

        mode = "DRY RUN" if dry_run else "run"
        logger.info("Starting %s of %d job(s): %s", mode, len(jobs),
                    ", ".join(j.name for j in jobs))

        # Pre-flight numbering/purge warnings (Issue 1) -- never hard errors
        # (an existing working config must not start failing runs over a new
        # warning), visible in the log and folded into the run summary.
        # known_job_names is every CONFIGURED job name (enabled or not), so a
        # disabled job's channels are never mistaken for orphaned by the
        # ownership pass. Wrapped defensively: this is advisory only and must
        # never block a real run.
        try:
            all_configured_jobs, _ = runner.jobs_from_settings(settings)
            known_job_names = {j.name for j in all_configured_jobs}
        except Exception:
            logger.exception("Could not resolve configured job names")
            all_configured_jobs = jobs
            known_job_names = {j.name for j in jobs}
        # Validated against every configured job (not the possibly
        # job_name-narrowed ``jobs``) so a "Run one job" invocation still
        # surfaces overlap/tie warnings against jobs not part of this run.
        try:
            config_warnings = runner.validate_job_number_ranges(all_configured_jobs)
        except Exception:
            logger.exception("Numbering/purge pre-flight validation failed")
            config_warnings = []
        for w in config_warnings:
            logger.warning("[CONFIG] %s", w)

        assign_epg = bool(settings.get("assign_epg", True))
        use_stream_logo = bool(settings.get("use_stream_logo", True))
        try:
            event_duration_hours = float(settings.get("event_duration_hours") or 3)
        except (TypeError, ValueError):
            event_duration_hours = 3.0
        if event_duration_hours <= 0:
            event_duration_hours = 3.0

        try:
            black_sample_seconds = float(settings.get("black_sample_seconds") or 5)
        except (TypeError, ValueError):
            black_sample_seconds = 5.0
        black_sample_seconds = max(3.0, min(30.0, black_sample_seconds))

        try:
            black_probe_budget = int(float(settings.get("black_probe_budget") or 80))
        except (TypeError, ValueError):
            black_probe_budget = 80
        enabled_black_job_names = [j.name for j in jobs if getattr(j, "check_black", False)]
        probe_plan, probe_surplus = engine.probe_budget_plan(black_probe_budget, enabled_black_job_names)
        # Shared across every event AND job in this run: caches probe verdicts
        # by stream id, and spends per-job reserves + a shared surplus pool
        # (see engine.probe_budget_plan / runner._select_unblack_streams).
        probe_state = {
            "cache": {},
            "sample_seconds": black_sample_seconds,
            "ffmpeg_missing_logged": False,
            "plan": probe_plan,
            "surplus": {"remaining": probe_surplus},
        }

        try:
            epg_link_tolerance_minutes = float(settings.get("epg_link_tolerance_minutes") or 90)
        except (TypeError, ValueError):
            epg_link_tolerance_minutes = 90.0

        # Auto-DVR (Replays) settings.
        def _num(key, default):
            try:
                return float(settings.get(key))
            except (TypeError, ValueError):
                return float(default)
        record_pre_pad_min = max(0.0, _num("record_pre_pad_min", 5))
        record_post_pad_min = max(0.0, _num("record_post_pad_min", 30))
        retention_days = int(max(0.0, _num("replay_retention_days", 14)))
        max_simultaneous_recordings = int(max(0.0, _num("max_simultaneous_recordings", 2)))
        # Teamarr-watch isn't tied to one job, so it uses these GLOBAL
        # settings (per-job jobs use their own record_shift_tolerance_hours/
        # record_max_extension_hours override -- see runner.JOB_FIELD_SPECS).
        teamarr_shift_tolerance_hours = max(0.0, _num("record_shift_tolerance_hours", 3))
        teamarr_max_extension_hours = max(0.0, _num("record_max_extension_hours", 2))

        xmltv_cache = {}
        totals = {"prepared": 0, "created": 0, "deleted": 0,
                  "skipped": 0, "preserved": 0, "errors": 0, "recorded": 0,
                  "capped": 0, "extended": 0, "rescheduled": 0,
                  "epg_scanned": 0, "epg_matched": 0,
                  "probes": 0, "probe_capped": 0,
                  "unnumbered": 0, "number_conflicts": 0,
                  "unowned_kept": 0, "adopted": 0,
                  "updated": 0, "update_deferred": 0}
        per_job = {}

        # One auto-DVR index snapshot for the whole run (not one per job) --
        # see load_auto_dvr_index()/ensure_recording() in runner.py. Updated
        # in place by every ensure_recording() call below (jobs AND the
        # teamarr watcher) so two matches for the same event within this one
        # run still dedup against each other.
        dvr_index = runner.load_auto_dvr_index(runner._recording_model())

        # One instance-wide channel-number index for the whole run (Issue 1)
        # -- mutated in place across jobs so job B sees job A's freshly
        # created numbers within the same run.
        try:
            number_index = runner.load_channel_number_index()
        except Exception:
            logger.exception("Could not load the channel-number index; numbering "
                             "allocator starts empty this run")
            number_index = set()
        # Spans must always be computed from every ENABLED, currently-configured
        # job -- never from the (possibly job_name-narrowed) ``jobs`` list --
        # so a "Run one job" invocation still sees every other enabled job's
        # range as a blocked range, exactly as a full run would. Mirrors the
        # known_job_names pattern above (re-read via jobs_from_settings).
        try:
            job_spans = runner.compute_job_number_spans(
                [j for j in all_configured_jobs if j.enabled])
        except Exception:
            logger.exception("Could not compute job number spans")
            job_spans = {}
        blocked_ranges = [(name, lo, hi) for name, (lo, hi) in job_spans.items()]

        # One channel-ownership registry for the whole run (Issue 2) --
        # mutated in place and saved by run_job after each job completes, and
        # a per-run set coordinating the one-shot-per-group adoption pass
        # (never persisted).
        try:
            channel_registry = runner.load_channel_registry(logger)
        except Exception:
            logger.exception("Could not load the channel registry; ownership "
                             "tracking is disabled this run")
            channel_registry = None
        adoption_state: set = set()

        for job in jobs:
            try:
                stats = runner.run_job(job, logger, dry_run=dry_run, xmltv_cache=xmltv_cache,
                                       assign_epg=assign_epg,
                                       event_duration_hours=event_duration_hours,
                                       use_stream_logo=use_stream_logo,
                                       probe_state=probe_state,
                                       record_pre_pad_min=record_pre_pad_min,
                                       record_post_pad_min=record_post_pad_min,
                                       max_simultaneous_recordings=max_simultaneous_recordings,
                                       dvr_index=dvr_index,
                                       number_index=number_index,
                                       blocked_ranges=blocked_ranges,
                                       job_number_end=job_spans.get(job.name, (None, None))[1],
                                       channel_registry=channel_registry,
                                       known_job_names=known_job_names,
                                       adoption_state=adoption_state,
                                       epg_link_tolerance_minutes=epg_link_tolerance_minutes)
                per_job[job.name] = stats
                for k in totals:
                    totals[k] += stats.get(k, 0)
            except Exception as e:
                logger.exception("Job '%s' failed", job.name)
                per_job[job.name] = {"error": str(e)}
                totals["errors"] += 1

        # Teamarr-group watcher: auto-record matching Teamarr event channels.
        teamarr_stats = None
        try:
            teamarr_stats = runner.run_teamarr_watch(
                runner._as_lines(settings.get("record_teamarr_groups")),
                runner._as_lines(settings.get("record_teamarr_patterns")),
                runner._as_lines(settings.get("record_teamarr_exclude")),
                logger, dry_run, event_duration_hours,
                record_pre_pad_min, record_post_pad_min,
                max_simultaneous=max_simultaneous_recordings,
                dvr_index=dvr_index,
                shift_tolerance_hours=teamarr_shift_tolerance_hours,
                max_extension_hours=teamarr_max_extension_hours)
            totals["recorded"] += teamarr_stats.get("created", 0)
            totals["extended"] += teamarr_stats.get("extended", 0)
            totals["rescheduled"] += teamarr_stats.get("rescheduled", 0)
            totals["capped"] += teamarr_stats.get("capped", 0)
            totals["errors"] += teamarr_stats.get("errors", 0)
        except Exception as e:
            logger.exception("Teamarr watcher failed")
            totals["errors"] += 1
            per_job["__teamarr__"] = {"error": str(e)}

        # Retention: prune aged / failed auto-DVR recordings (files + rows).
        retention_stats = None
        try:
            retention_stats = runner.run_retention(retention_days, logger, dry_run)
        except Exception as e:
            logger.exception("Retention pass failed")
            totals["errors"] += 1
            per_job["__retention__"] = {"error": str(e)}

        # Tombstone/creation-state pruning: once per full run, not once per
        # created recording (see prune_dvr_tombstones()'s docstring).
        if not dry_run:
            try:
                runner.prune_dvr_tombstones(logger)
            except Exception:
                logger.exception("Tombstone pruning failed")
            if channel_registry is not None:
                try:
                    from apps.channels.models import Channel
                    existing_ids = set(Channel.objects.values_list("id", flat=True))
                    runner.prune_channel_registry(channel_registry, existing_ids, logger)
                    runner.save_channel_registry(channel_registry, logger)
                except Exception:
                    logger.exception("Channel registry pruning failed")

        updated_clause = ""
        if totals['updated'] or totals['update_deferred']:
            updated_clause = f", {totals['updated']} updated in place"
            if totals['update_deferred']:
                updated_clause += f" ({totals['update_deferred']} stream-swap deferred)"

        prefix = "[DRY RUN] " if dry_run else ""
        summary = (f"{prefix}Sports Auto-Creator: {totals['created']} created, "
                   f"{totals['deleted']} deleted, {totals['skipped']} skipped, "
                   f"{totals['recorded']} recorded, {totals['extended']} extended, "
                   f"{totals['rescheduled']} rescheduled, "
                   f"{totals['capped']} capped (max_simultaneous) "
                   f"across {len(jobs)} job(s) — considered {totals['prepared']} "
                   f"event(s), scanned {totals['epg_scanned']} EPG programme(s), "
                   f"{totals['epg_matched']} matched"
                   + (f", {retention_stats['deleted']} recording(s) pruned"
                      if retention_stats and retention_stats.get("deleted") else "")
                   + (f", {totals['probes']} black-screen probe(s) "
                      f"({totals['probe_capped']} capped)"
                      if totals['probes'] or totals['probe_capped'] else "")
                   + (f", {totals['unnumbered']} unnumbered"
                      if totals['unnumbered'] else "")
                   + (f", {totals['number_conflicts']} number conflict(s) resolved"
                      if totals['number_conflicts'] else "")
                   + (f", {totals['adopted']} channel(s) adopted"
                      if totals['adopted'] else "")
                   + (f", {totals['unowned_kept']} unowned channel(s) kept"
                      if totals['unowned_kept'] else "")
                   + updated_clause
                   + (f" — {totals['errors']} error(s)" if totals['errors'] else "")
                   + (f" — {len(config_errors)} misconfigured job(s) skipped"
                      if config_errors else "")
                   + (f" — {len(config_warnings)} configuration warning(s)"
                      if config_warnings else ""))
        logger.info(summary)
        run_success = totals["errors"] == 0 and not config_errors
        _notify(summary, success=run_success,
                refresh_channels=not dry_run and (totals["created"] > 0 or totals["deleted"] > 0))

        _write_last_run({"status": "ok", "dry_run": dry_run, "job_name": job_name,
                         "summary": summary, "jobs": per_job, "errors": config_errors},
                        mark_success=run_success and not dry_run)
        return {"status": "ok", "summary": summary, "jobs": per_job}
    except Exception as e:
        # Top-level safety net: anything that escapes every per-job/per-
        # teamarr/per-retention try/except above (a bug in the orchestration
        # itself, not in one job) still gets a write, a notification, and a
        # status distinct from a normal per-job "error" -- so the status
        # display can tell "one job misconfigured" apart from "the whole run
        # blew up".
        logger.exception("Sports Auto-Creator: task crashed")
        _write_last_run({
            "status": "crashed",
            "error": f"{type(e).__name__}: {e}",
            "traceback": traceback.format_exc()[-4000:],
            "dry_run": dry_run,
            "job_name": job_name,
        })
        _notify("Sports Auto-Creator: the run CRASHED — see the celery log", success=False)
        return {"status": "crashed", "message": str(e)}
    finally:
        # `close_old_connections`/`cache` may still be None if the import
        # itself is what failed (see the top of the function) -- guard both
        # so this block can never itself raise NameError on top of whatever
        # already went wrong.
        if close_old_connections is not None:
            close_old_connections()
        if lock_acquired and cache is not None:
            try:
                cache.delete(lock_key)
            except Exception:
                logger.debug("Failed to release run lock", exc_info=True)


def _notify(message: str, success: bool = True, refresh_channels: bool = False) -> None:
    """Best-effort websocket toast so results are visible in the UI."""
    try:
        from core.utils import send_websocket_update
        send_websocket_update(
            "updates",
            "update",
            {
                "success": success,
                "type": "plugin",
                "plugin": PLUGIN_KEY,
                "refresh_channels": refresh_channels,
                "message": message,
            },
        )
    except Exception:
        logger.debug("Websocket notify failed", exc_info=True)
